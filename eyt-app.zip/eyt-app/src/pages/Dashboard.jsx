import { useState } from "react";
import { IconUser, IconLogout, IconChart } from "../components/Icons";
import { clearSession } from "../utils/storage";

// ── Datos de ejemplo (reemplaza con tu API o estado global) ───────
const SAMPLE_TASKS = [
  { id: 1, titulo: "Revisar informe Q1", fecha: "01/02/25", vence: true  },
  { id: 2, titulo: "Reunión de equipo",  fecha: "01/02/25", vence: false },
  { id: 3, titulo: "Enviar propuesta",   fecha: "01/02/25", vence: false },
];

const NAV_ITEMS = ["TAREAS", "RENDIMIENTO", "PERFIL"];

export function Dashboard({ user, onLogout }) {
  const [activeNav, setActiveNav] = useState("TAREAS");
  const [tasks]                   = useState(SAMPLE_TASKS);

  const vencen = tasks.filter((t) => t.vence).length;

  const handleLogout = () => {
    clearSession();
    onLogout();
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden" style={{ fontFamily: "'Georgia', serif" }}>

      {/* ── Sidebar ─────────────────────────────────────────────── */}
      <aside
        className="w-36 flex-shrink-0 flex flex-col bg-white border-r border-gray-100"
        style={{ boxShadow: "2px 0 12px rgba(0,0,0,0.04)" }}
      >
        {/* Logo */}
        <div className="px-5 pt-6 pb-8">
          <span
            className="text-2xl font-black tracking-tight"
            style={{ color: "#c8a84b", letterSpacing: "-1px" }}
          >
            EYT
          </span>
        </div>

        {/* Navegación */}
        <nav className="flex flex-col gap-1 flex-1 px-3">
          {NAV_ITEMS.map((item) => (
            <button
              key={item}
              onClick={() => setActiveNav(item)}
              className={`text-left px-3 py-3 rounded-xl text-xs font-bold tracking-widest transition-all ${
                activeNav === item
                  ? "text-gray-900 bg-amber-50 border-l-2"
                  : "text-gray-400 hover:text-gray-600 hover:bg-gray-50"
              }`}
              style={activeNav === item ? { borderColor: "#c8a84b" } : {}}
            >
              {item}
            </button>
          ))}
        </nav>

        {/* Usuario + Cerrar sesión */}
        <div className="px-4 pb-6 flex flex-col items-center gap-3">
          <div
            className="w-10 h-10 rounded-full flex items-center justify-center"
            style={{ background: "#f0e8c8" }}
          >
            <IconUser />
          </div>
          <span className="text-xs text-gray-500 font-semibold text-center leading-tight">
            {user.nombre} {user.apellido}
          </span>
          <button
            onClick={handleLogout}
            title="Cerrar sesión"
            className="flex items-center gap-1 text-xs text-gray-400 hover:text-red-500 transition-colors"
          >
            <IconLogout />
          </button>
        </div>
      </aside>

      {/* ── Contenido principal ─────────────────────────────────── */}
      <main
        className="flex-1 overflow-auto"
        style={{ background: "linear-gradient(180deg, #fdfaf3 0%, #e8dba8 100%)" }}
      >
        {/* Barra superior */}
        <div className="flex items-center justify-between px-10 py-5 border-b border-amber-100 bg-white bg-opacity-70">
          <h2 className="text-base font-black tracking-widest text-gray-700">{activeNav}</h2>
          {activeNav === "TAREAS" && (
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-gray-500 tracking-wide uppercase">
                Por Vencer
              </span>
              <span
                className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white"
                style={{ background: "#e05252" }}
              >
                {vencen}
              </span>
            </div>
          )}
        </div>

        {/* ── Sección TAREAS ── */}
        {activeNav === "TAREAS" && (
          <div className="p-10 flex justify-end">
            <div
              className="rounded-2xl overflow-hidden shadow-lg"
              style={{ background: "#c8a84b", minWidth: 260 }}
            >
              {/* Encabezado tabla */}
              <div className="grid grid-cols-2 text-center py-2 px-4 gap-2">
                <span className="text-xs font-black text-white tracking-widest uppercase">
                  ID Tarea
                </span>
                <span className="text-xs font-black text-white tracking-widest uppercase leading-tight">
                  Fecha de<br />Finalización
                </span>
              </div>
              {/* Filas */}
              {tasks.map((task, i) => (
                <div
                  key={task.id}
                  className={`grid grid-cols-2 text-center py-2.5 px-4 gap-2 ${
                    i % 2 === 0 ? "bg-amber-200" : "bg-amber-100"
                  }`}
                >
                  <span className="text-xs font-bold text-amber-900">{task.id}</span>
                  <span className="text-xs font-bold text-amber-900">{task.fecha}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── Sección RENDIMIENTO ── */}
        {activeNav === "RENDIMIENTO" && (
          <div className="p-10 flex flex-col items-center justify-center h-64 gap-3">
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center"
              style={{ background: "#f0e8c8" }}
            >
              <IconChart />
            </div>
            <p className="text-sm text-gray-500 font-semibold">Próximamente</p>
          </div>
        )}

        {/* ── Sección PERFIL ── */}
        {activeNav === "PERFIL" && (
          <div className="p-10">
            <div className="max-w-sm bg-white rounded-2xl shadow-md p-8 flex flex-col gap-4">
              <div className="flex items-center gap-4">
                <div
                  className="w-16 h-16 rounded-full flex items-center justify-center text-xl font-black"
                  style={{ background: "#f0e8c8", color: "#a8882a" }}
                >
                  {user.nombre[0]}{user.apellido[0]}
                </div>
                <div>
                  <p className="font-black text-gray-800 text-lg">
                    {user.nombre} {user.apellido}
                  </p>
                  <p className="text-xs text-gray-400">{user.email}</p>
                </div>
              </div>
              <div className="h-px bg-gray-100" />
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-xs text-gray-400 uppercase tracking-wide mb-1">Teléfono</p>
                  <p className="font-semibold text-gray-700">{user.telefono}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400 uppercase tracking-wide mb-1">Año Nac.</p>
                  <p className="font-semibold text-gray-700">{user.anio}</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
